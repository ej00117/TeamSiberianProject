Sprint 4 - Traffic Generator Instructions

Overview:
This project runs BookStack and Umami using Docker Compose and uses a Selenium script to generate traffic that is tracked in Umami.

Requirements:
- Docker Desktop installed and running

Steps:

1. Start the project
Run this in the folder with compose.yaml:
docker compose up -d --build

2. Open the apps
BookStack: http://localhost:8080
-Credentials:
	Email: admin@admin.com
	Password: password

Umami: http://localhost:3000
-Credentials:
	Username: admin
	Password: umami

3. Run traffic generator
	a. docker compose run --rm traffic_generator (This will Run the Traffic Generator but wont be tracked by Umami)
	b. Run the python script traffic.py manually (This will Run the Traffic Generator, and this will be tracked by Umami)

4. Check results
- Go to Umami dashboard
- You should see visits and pageviews increasing

Notes:
- Traffic is generated using Selenium (headless browser)
- DISABLE_BOT_CHECK is enabled so traffic is counted
- All services run inside Docker
- Folders are mounted so there should be no need to set up Bookstack or Umami
