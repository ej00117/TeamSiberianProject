import time
import random
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

TARGET_URL = "http://localhost:8080"
VISITS = 10

options = Options()
# Comment this out if you want to watch the browser open
options.add_argument("--headless=new")

for i in range(VISITS):
    driver = webdriver.Chrome(options=options)
    try:
        print(f"Visit {i+1} -> {TARGET_URL}")
        driver.get(TARGET_URL)
        time.sleep(random.uniform(3, 5))
        print("Current URL:", driver.current_url)
        print("Title:", driver.title)
    except Exception as e:
        print(f"Visit {i+1} failed: {e}")
    finally:
        driver.quit()