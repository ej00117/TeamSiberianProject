SETUP AND LOGIN:

1. Go thorugh the setup process without changing any setting.
2. When asked to create new or reuse database. Select Reuse database.

---CREDENTIALS---
Username: Admin
Password: Admin123