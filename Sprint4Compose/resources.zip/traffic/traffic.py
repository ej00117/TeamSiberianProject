import time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

BOOKSTACK_URL = "http://host.docker.internal:8080"
BOOKSTACK_PAGES = ["/", "/books", "/shelves", "/create-book", "/create-shelf"]
DURATION = 60

def create_driver():
    options = Options()
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-gpu")
    options.add_argument("--ignore-certificate-errors")
    options.add_argument("--window-size=1920,1080")
    options.add_argument("--lang=en-US")
    options.add_argument(
        "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    )
    return webdriver.Remote(
        command_executor="http://chrome:4444/wd/hub",
        options=options
    )
    
def login(driver):
    driver.get(BOOKSTACK_URL + "/login")
    wait_for_page(driver)

    email_input = driver.find_element(By.ID, "email")
    email_input.send_keys("admin@admin.com")

    password_input = driver.find_element(By.ID, "password")
    password_input.send_keys("password")

    submit_button = driver.find_element(By.CSS_SELECTOR, "button.button")
    submit_button.click()

    wait_for_page(driver)
    print("logged in")
    

def wait_for_page(driver):
    for _ in range(20):
        if driver.execute_script("return document.readyState") == "complete":
            return
        time.sleep(0.2)

def visit(driver, path):
    driver.get(BOOKSTACK_URL + path)
    wait_for_page(driver)
    print(f"loaded {BOOKSTACK_URL + path}")
    time.sleep(2)

def run():
    print("starting script")
    driver = create_driver()
    start = time.time()
    try:
        login(driver)
        
        while time.time() - start < DURATION:
            for page in BOOKSTACK_PAGES:
                visit(driver, page)
                if time.time() - start >= DURATION:
                    break
    finally:
        print("finished 1 minute of traffic")
        driver.quit()

run()